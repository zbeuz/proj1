=== INFORMATIONS SUR LE TRAVAIL ===
Titre : FINALISER LA DOC!!!!!!
Description : Vous connaissez l'importance de la doc
Section : SLAM
Période : du 12/06/2025 au 13/06/2025
Date de génération de l'archive : 12/06/2025 à 14:04:20
Nombre de dépôts : 1

=== LISTE DES DÉPÔTS ===

01. Martha GONTIER
   Date de dépôt : 12/06/2025 à 13:59
   Instructions : OUI (voir fichier Instructions_Martha GONTIER.txt)
   Fichier indiqué mais non trouvé : devoir_1749736793_684add59ed23f.docx
   -----------------------------------------

=== RÉSUMÉ ===
Total des élèves ayant déposé : 1
Élèves avec fichiers : 1
Élèves avec instructions : 1
