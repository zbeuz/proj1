=== INFORMATIONS SUR LE TRAVAIL ===
Titre : bonjour
Description : whfhwfuwhfu
Section : MELEC
Période : du 12/06/2025 au 30/06/2025
Date de génération de l'archive : 12/06/2025 à 11:26:54
Nombre de dépôts : 1

=== LISTE DES DÉPÔTS ===

01. Jean Dupont
   Date de dépôt : 12/06/2025 à 00:30
   Instructions : OUI (voir fichier Instructions_Jean Dupont.txt)
   Fichier déposé : OUI (01_Jean_Dupont/Devoir_Jean Dupont.pdf)
   Taille du fichier : 212.02 KB
   -----------------------------------------

=== RÉSUMÉ ===
Total des élèves ayant déposé : 1
Élèves avec fichiers : 1
Élèves avec instructions : 1
